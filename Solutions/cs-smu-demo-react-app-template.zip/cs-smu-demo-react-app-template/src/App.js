export const App = () => {
  return <div>Hi there</div>;
};
